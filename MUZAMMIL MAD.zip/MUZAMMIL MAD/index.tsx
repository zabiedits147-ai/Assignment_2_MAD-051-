import { useState } from 'react';
import {
  Alert,
  FlatList,
  SafeAreaView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';

type Priority = 0 | 1 | 2;

interface Task {
  id: string;
  text: string;
  done: boolean;
  priority: Priority;
}

const PRIORITY_COLORS: Record<Priority, string> = {
  0: '#e040fb', // High   → Pink
  1: '#7c4dff', // Medium → Purple
  2: '#b39ddb', // Low    → Light Purple
};

let counter = 0;
const uid = () => `task_${Date.now()}_${++counter}`;

const INITIAL_TASKS: Task[] = [
  { id: uid(), text: 'Buy groceries 🛒', done: false, priority: 1 },
  { id: uid(), text: 'Finish assignment 🔥', done: false, priority: 0 },
  { id: uid(), text: 'Call mom 📞', done: true, priority: 2 },
];

export default function App() {
  const [tasks, setTasks]         = useState<Task[]>(INITIAL_TASKS);
  const [inputText, setInputText] = useState('');
  const [filter, setFilter]       = useState<'all' | 'active' | 'done'>('all');
  const [priority, setPriority]   = useState<Priority>(1);

  const totalCount  = tasks.length;
  const doneCount   = tasks.filter(t => t.done).length;
  const activeCount = totalCount - doneCount;

  const visibleTasks = tasks.filter(t => {
    if (filter === 'active') return !t.done;
    if (filter === 'done')   return  t.done;
    return true;
  });

  const addTask = () => {
    const text = inputText.trim();
    if (!text) {
      Alert.alert('Empty Field', 'Please write something first!');
      return;
    }
    setTasks(prev => [{ id: uid(), text, done: false, priority }, ...prev]);
    setInputText('');
  };

  const toggleDone = (id: string) => {
    setTasks(prev =>
      prev.map(t => t.id === id ? { ...t, done: !t.done } : t)
    );
  };

  const removeTask = (id: string) => {
    Alert.alert(
      'Delete Task?',
      'Are you sure you want to delete this task?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: () => setTasks(prev => prev.filter(t => t.id !== id)),
        },
      ]
    );
  };

  const clearDone = () => {
    Alert.alert(
      'Clear Completed?',
      `${doneCount} completed tasks will be removed.`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Clear',
          style: 'destructive',
          onPress: () => setTasks(prev => prev.filter(t => !t.done)),
        },
      ]
    );
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar backgroundColor="#7c4dff" barStyle="light-content" />

      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.headerTitle}>My Tasks ✨</Text>
          <Text style={styles.headerSub}>STAY ON TOP OF YOUR DAY</Text>
        </View>
        <View style={styles.headerBadge}>
          <Text style={styles.headerBadgeNum}>{activeCount}</Text>
          <Text style={styles.headerBadgeLbl}>left</Text>
        </View>
      </View>

      {/* Stats Bar */}
      <View style={styles.statsBar}>
        <View style={styles.statItem}>
          <Text style={styles.statNum}>{totalCount}</Text>
          <Text style={styles.statLbl}>TOTAL</Text>
        </View>
        <View style={styles.statDivider} />
        <View style={styles.statItem}>
          <Text style={styles.statNum}>{activeCount}</Text>
          <Text style={styles.statLbl}>ACTIVE</Text>
        </View>
        <View style={styles.statDivider} />
        <View style={styles.statItem}>
          <Text style={styles.statNum}>{doneCount}</Text>
          <Text style={styles.statLbl}>DONE</Text>
        </View>
      </View>

      {/* Priority Selector */}
      <View style={styles.priorityRow}>
        <Text style={styles.priorityTitle}>Priority: </Text>
        {([0, 1, 2] as Priority[]).map(p => (
          <TouchableOpacity
            key={p}
            onPress={() => setPriority(p)}
            style={[
              styles.priorityDot,
              { backgroundColor: PRIORITY_COLORS[p] },
              priority !== p && styles.priorityDotInactive,
            ]}
          />
        ))}
        <Text style={styles.priorityLabel}>
          {['High', 'Medium', 'Low'][priority]}
        </Text>
      </View>

      {/* Input Row */}
      <View style={styles.inputRow}>
        <TextInput
          style={styles.input}
          placeholder="Add a new task…"
          placeholderTextColor="#ce93d8"
          value={inputText}
          onChangeText={setInputText}
          onSubmitEditing={addTask}
          returnKeyType="done"
        />
        <TouchableOpacity style={styles.addBtn} onPress={addTask}>
          <Text style={styles.addBtnText}>+</Text>
        </TouchableOpacity>
      </View>

      {/* Filter Tabs */}
      <View style={styles.filterRow}>
        {(['all', 'active', 'done'] as const).map(f => (
          <TouchableOpacity
            key={f}
            style={[styles.filterBtn, filter === f && styles.filterBtnActive]}
            onPress={() => setFilter(f)}
          >
            <Text style={[
              styles.filterBtnText,
              filter === f && styles.filterBtnTextActive,
            ]}>
              {f.toUpperCase()}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Task List */}
      <FlatList
        data={visibleTasks}
        keyExtractor={item => item.id}
        style={styles.list}
        ListEmptyComponent={
          <View style={styles.emptyBox}>
            <Text style={styles.emptyIcon}>
              {filter === 'done' ? '🎉' : '✏️'}
            </Text>
            <Text style={styles.emptyText}>
              {filter === 'done'
                ? 'Nothing completed yet!'
                : 'No tasks — add one above!'}
            </Text>
          </View>
        }
        renderItem={({ item }) => (
          <View style={styles.taskRow}>
            {/* Priority Bar */}
            <View style={[
              styles.taskBar,
              { backgroundColor: PRIORITY_COLORS[item.priority] }
            ]} />

            {/* Checkbox */}
            <TouchableOpacity
              style={[styles.checkbox, item.done && styles.checkboxDone]}
              onPress={() => toggleDone(item.id)}
            >
              {item.done && <Text style={styles.checkmark}>✓</Text>}
            </TouchableOpacity>

            {/* Task Text */}
            <Text style={[
              styles.taskText,
              item.done && styles.taskTextDone,
            ]}>
              {item.text}
            </Text>

            {/* Delete Button */}
            <TouchableOpacity onPress={() => removeTask(item.id)}>
              <Text style={styles.delBtn}>✕</Text>
            </TouchableOpacity>
          </View>
        )}
        ItemSeparatorComponent={() => <View style={styles.separator} />}
      />

      {/* Clear Completed */}
      {doneCount > 0 && (
        <TouchableOpacity style={styles.clearBtn} onPress={clearDone}>
          <Text style={styles.clearBtnText}>
            🧹 Clear Completed ({doneCount})
          </Text>
        </TouchableOpacity>
      )}
    </SafeAreaView>
  );
}

// ── Colors ───────────────────────────────────────────────
const BG       = '#faf5ff'; // very light purple background
const BG2      = '#f3e5f5'; // soft pink-purple
const PURPLE   = '#7c4dff'; // main purple
const PINK     = '#e040fb'; // hot pink accent
const INK      = '#1a0033'; // dark purple ink
const INK2     = '#7b5ea7'; // muted purple
const BORDER   = '#e1bee7'; // light purple border
const DONE_C   = '#ce93d8'; // done purple

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: BG },

  // Header
  header: {
    backgroundColor: PURPLE,
    paddingHorizontal: 24,
    paddingVertical: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 26,
    fontWeight: '800',
    color: '#fff',
    letterSpacing: 0.5,
  },
  headerSub: {
    fontSize: 9,
    color: 'rgba(255,255,255,0.7)',
    marginTop: 3,
    letterSpacing: 1.5,
  },
  headerBadge: {
    backgroundColor: PINK,
    borderRadius: 14,
    paddingHorizontal: 14,
    paddingVertical: 8,
    alignItems: 'center',
  },
  headerBadgeNum: {
    fontSize: 22,
    fontWeight: '800',
    color: '#fff',
    lineHeight: 24,
  },
  headerBadgeLbl: {
    fontSize: 9,
    color: 'rgba(255,255,255,0.85)',
    letterSpacing: 1,
  },

  // Stats
  statsBar: {
    flexDirection: 'row',
    backgroundColor: BG2,
    borderBottomWidth: 1,
    borderBottomColor: BORDER,
  },
  statItem: { flex: 1, alignItems: 'center', paddingVertical: 12 },
  statNum: { fontSize: 20, fontWeight: '700', color: PURPLE },
  statLbl: { fontSize: 9, color: INK2, letterSpacing: 1, marginTop: 2 },
  statDivider: { width: 1, backgroundColor: BORDER, marginVertical: 8 },

  // Priority
  priorityRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 10,
    gap: 8,
    borderBottomWidth: 1,
    borderBottomColor: BORDER,
    backgroundColor: BG,
  },
  priorityTitle: { fontSize: 13, color: INK2, fontWeight: '500' },
  priorityDot: { width: 16, height: 16, borderRadius: 8 },
  priorityDotInactive: { opacity: 0.25 },
  priorityLabel: { fontSize: 12, color: PURPLE, marginLeft: 2, fontWeight: '600' },

  // Input
  inputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 10,
    borderBottomWidth: 1,
    borderBottomColor: BORDER,
    backgroundColor: BG,
  },
  input: {
    flex: 1,
    fontSize: 15,
    color: INK,
    backgroundColor: BG2,
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderWidth: 1.5,
    borderColor: BORDER,
  },
  addBtn: {
    width: 44,
    height: 44,
    borderRadius: 14,
    backgroundColor: PINK,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 4,
    shadowColor: PINK,
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.4,
    shadowRadius: 6,
  },
  addBtnText: { color: '#fff', fontSize: 26, lineHeight: 30, fontWeight: '300' },

  // Filters
  filterRow: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    paddingVertical: 10,
    gap: 8,
    borderBottomWidth: 1,
    borderBottomColor: BORDER,
    backgroundColor: BG,
  },
  filterBtn: {
    paddingHorizontal: 16,
    paddingVertical: 6,
    borderRadius: 20,
    borderWidth: 1.5,
    borderColor: BORDER,
    backgroundColor: BG,
  },
  filterBtnActive: {
    backgroundColor: PURPLE,
    borderColor: PURPLE,
  },
  filterBtnText: { fontSize: 10, color: INK2, fontWeight: '700', letterSpacing: 0.5 },
  filterBtnTextActive: { color: '#fff' },

  // List
  list: { flex: 1, backgroundColor: BG },
  emptyBox: { alignItems: 'center', paddingVertical: 70 },
  emptyIcon: { fontSize: 48, marginBottom: 12 },
  emptyText: { fontSize: 15, color: DONE_C },

  // Task Row
  taskRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 16,
    gap: 12,
    backgroundColor: BG,
  },
  taskBar: { width: 4, height: 36, borderRadius: 4 },
  checkbox: {
    width: 24,
    height: 24,
    borderRadius: 8,
    borderWidth: 2,
    borderColor: BORDER,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: BG2,
  },
  checkboxDone: { backgroundColor: DONE_C, borderColor: DONE_C },
  checkmark: { color: '#fff', fontSize: 13, fontWeight: '800' },
  taskText: { flex: 1, fontSize: 15, color: INK, fontWeight: '400' },
  taskTextDone: { color: DONE_C, textDecorationLine: 'line-through' },
  delBtn: { color: BORDER, fontSize: 15, padding: 4, fontWeight: '600' },
  separator: { height: 1, backgroundColor: BORDER, marginLeft: 56 },

  // Footer
  clearBtn: {
    margin: 12,
    padding: 13,
    borderRadius: 14,
    borderWidth: 1.5,
    borderColor: BORDER,
    alignItems: 'center',
    backgroundColor: BG2,
  },
  clearBtnText: { color: PURPLE, fontSize: 13, fontWeight: '600' },
});